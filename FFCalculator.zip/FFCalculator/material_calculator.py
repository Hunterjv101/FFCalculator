import math
import numpy as np
import os
from master_material import MasterMaterial

def main():

    cwd = os.getcwd()
    results_dir = os.path.join(cwd,"Results")
    user_input_dir = os.path.join(cwd,"Input")

    # Retrieve parsed user mats
    total_mat_list = get_user_mats(user_input_dir)
    
    # Output user mats in console and in text file for logging
    print_file_mats(total_mat_list, results_dir)
    component_list = calculate_component_list(total_mat_list)
    export_final_components(component_list, results_dir)

def get_user_mats(user_input_dir):
    total_mat_list = []

    with open(user_input_dir+"/mat_list.txt",'r') as f:
        content = f.read()

        for mat in content.split('-'): # iterate through master_materials
            print('\n')
            master_mat_name = "" # name of master material
            master_mat_count = 1 # count of master material
            shopping_list = [] # list of sub materials

            for line,matitem in enumerate(mat.strip().split('\n')): # iterate through each line item for each material
                if line == 0:
                    master_mat_name = matitem[:-1] # get rid of colon
                    master_mat_count = int(input(f"How many {master_mat_name}'s do need?"))
                    if master_mat_count == 0: # go next mat
                        break
                else:
                    mat_tuple = tuple(matitem.split('\t'))
                    shopping_list.append(mat_tuple)

            if master_mat_count > 0:
                complete_mat = MasterMaterial(name=master_mat_name)
                complete_mat.dictify_component_items(shopping_list)
                # Multiply components by the total amount of master materials wanted
                components = complete_mat.get_component_items()

                for name,amount in components.items():
                    components.update({
                        name: (int(amount)*int(master_mat_count))
                    })
                print(f"{complete_mat.name}:\n{complete_mat.components}")
                complete_mat.components = components
                complete_mat.set_material_count(master_mat_count)
                total_mat_list.append(complete_mat)
    return total_mat_list

def print_file_mats(materials_list, results_dir):
    """
    This function is ran first so file open has write privaleges
    """
    material_names = [material.name for material in materials_list]
    material_counts = [material.mat_count for material in materials_list]

    f = open(results_dir+"/component_counts.txt",'w')
    
    # Print names of materials accounted for in the base components and their quantities
    print("\n\n|...Materials accounted for in application...");f.write("|...Materials accounted for in application...\n")
    for name,count in zip(material_names,material_counts):
        print(''.join(np.repeat("-",40)))
        print(f"{name:<30}\t{count}")
        f.write(f"{''.join(np.repeat('-',40))}\n")
        f.write(f"{name:<30}\t{count}\n")
    
    f.write('\n\n\n')
    f.close()

def calculate_component_list(materials_list):
    base_components = [material.components for material in materials_list] # list of component dictionaries

    final_component_count = base_components[0]

    for index,mat_components in enumerate(base_components[1:]):
        for component,amount in mat_components.items():
            if component in final_component_count.keys():
                final_component_count[component]+=int(amount)
            else:
                final_component_count.update({
                    component:int(amount)
                })

    return final_component_count

def export_final_components(final_materials_list, results_dir):
    f = open(results_dir+"/component_counts.txt",'a')

    print('\n\n|...Final Material Counts:\n')
    for material,amount in final_materials_list.items():
        print(f'{material:<30} Count: {amount}')
        f.write(f'{material:<30} Count: {amount}\n')
    
    f.close()

if __name__ == "__main__":
    main()