class MasterMaterial:
    def __init__(self, name): # pass basic material name into class
        self.name = name

    def dictify_component_items(self,components_list): # list of tuples
        component_dict = {}
        for pair in components_list:
            try:
                component_dict.update({
                    pair[0]:pair[1] # name:amount
                })
            except:
                continue
        self.components = component_dict
    
    def set_material_count(self,mat_count):
        self.mat_count = mat_count

    def get_component_items(self):
        return self.components
